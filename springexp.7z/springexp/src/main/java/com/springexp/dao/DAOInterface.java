package com.springexp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springexp.Entity.Product;

@Repository
public interface DAOInterface extends JpaRepository <Product,String>
 {
	

}
