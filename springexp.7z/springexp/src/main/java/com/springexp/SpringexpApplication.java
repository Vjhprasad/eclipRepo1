package com.springexp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringexpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringexpApplication.class, args);
	}

}
