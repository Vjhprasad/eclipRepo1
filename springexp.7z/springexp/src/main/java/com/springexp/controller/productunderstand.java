package com.springexp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springexp.Entity.Product;
import com.springexp.service.ServiceInterface;
@RestController
public class productunderstand {
	@Autowired
private ServiceInterface ss;	
@PostMapping("createProductDetails")
public String create(@RequestBody Product p1) {
	int i=ss.createProduct(p1);
	if(i>0) {
		
	return "Product created";
	}
	else 
		return "not created";
}
}
