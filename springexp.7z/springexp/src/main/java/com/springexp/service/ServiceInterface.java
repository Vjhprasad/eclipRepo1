package com.springexp.service;

import com.springexp.Entity.Product;

public interface ServiceInterface {


		int createProduct(Product p1);
	}

