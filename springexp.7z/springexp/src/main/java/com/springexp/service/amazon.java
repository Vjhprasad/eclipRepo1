package com.springexp.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springexp.Entity.Product;
import com.springexp.dao.DAOInterface;
@Service
@Transactional

public class amazon implements ServiceInterface{

	@Autowired
	private DAOInterface dd;
		@Override
		public int createProduct(Product p1) {
	    int i=0;
	    dd.save(p1);
	    i=1;
	   
			return i;
		}
		
}
