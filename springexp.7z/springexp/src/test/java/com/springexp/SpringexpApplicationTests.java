package com.springexp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringexpApplicationTests {

	@Test
	void contextLoads() {
	}

}
